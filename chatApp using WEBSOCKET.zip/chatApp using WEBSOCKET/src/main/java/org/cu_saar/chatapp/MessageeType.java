package org.cu_saar.chatapp;

public enum MessageeType {
    CHAT,
    JOIN,
    LEAVE
}
